#include <iostream>
#include <cstdlib>
using namespace std;

int main ()
{
    int num1, num2, soma;

    cout << "Soma de dois numeros";

    cout << "Entre com o primeiro numero: " ;
    cin >> num1;

    cout << "Entre com o segundo numero: ";
    cin >> num2;

    soma = num1 + num2;

    cout << "A soma e: ";
    cout << soma;

    system ("pause > 0");

    return 0;
}
